from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# API router'ını içe aktar (eğer api klasöründe router.py varsa)
try:
    from backend.fastapi.api.router import api_router # type: ignore
except:
    from .api.router import api_router # type: ignore

app = FastAPI(
    title="DesignPilot API",
    version="1.0.0",
)

# CORS Ayarları
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # frontend origin buraya eklenebilir
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API route'ları dahil et
app.include_router(api_router)

@app.get("/")
def root():
    return {"message": "DesignPilot API is running!"}
